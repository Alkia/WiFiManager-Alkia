/**************************************************************
   WiFiManager is a library for the ESP8266/Arduino platform
   (https://github.com/esp8266/Arduino) to enable easy
   configuration and reconfiguration of WiFi credentials using a Captive Portal
   inspired by:
   http://www.esp8266.com/viewtopic.php?f=29&t=2520
   https://github.com/chriscook8/esp-arduino-apboot
   https://github.com/esp8266/Arduino/tree/esp8266/hardware/esp8266com/esp8266/libraries/DNSServer/examples/CaptivePortalAdvanced
   Built by AlexT https://github.com/tzapu
   Licensed under MIT license
 **************************************************************/

#ifndef WiFiManager_h
#define WiFiManager_h

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <DNSServer.h>
#include <memory>

extern "C" {
  #include "user_interface.h"
}

const char HTTP_HEAD[] PROGMEM            = "<!DOCTYPE html><html lang=\"en\"><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\"/><title>{v}</title>";
const char HTTP_STYLE[] PROGMEM           = "<style>.c{text-align: center;} div,input{padding:5px;font-size:1em;} input{width:95%;} body{text-align: center;font-family:verdana;} button{border:0;border-radius:0.3rem;background-color:#1fa3ec;color:#fff;line-height:2.4rem;font-size:1.2rem;width:100%;} .q{float: right;width: 64px;text-align: right;} .l{background: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAALVBMVEX///8EBwfBwsLw8PAzNjaCg4NTVVUjJiZDRUUUFxdiZGSho6OSk5Pg4eFydHTCjaf3AAAAZElEQVQ4je2NSw7AIAhEBamKn97/uMXEGBvozkWb9C2Zx4xzWykBhFAeYp9gkLyZE0zIMno9n4g19hmdY39scwqVkOXaxph0ZCXQcqxSpgQpONa59wkRDOL93eAXvimwlbPbwwVAegLS1HGfZAAAAABJRU5ErkJggg==\") no-repeat left center;background-size: 1em;}</style>";
const char HTTP_SCRIPT[] PROGMEM          = "<script>function c(l){document.getElementById('s').value=l.innerText||l.textContent;document.getElementById('p').focus();}</script>";
const char HTTP_HEAD_END[] PROGMEM        = "</head><body><div style='text-align:left;display:inline-block;min-width:260px;'><center><img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAA2CAIAAAANokGgAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAgAElEQVR42u29d5gUxfY/fE5Vd09P2Jnd2cgGwi4ZFhCQLBmUKKggYoIr5oj5iveac7peM4pgJCiiJAEJAkqQzBKWvDmnmZ2Znunuqvr90cuykhW9X9/ntRj2WZqa7urTp074nNAohIC/zBBCIGLWoWKHKmWkxVv/hL/H/wcH+cutSMCWvXmEEAD4K/H83+O3DemvIKUEgCWXEHHn/sLakG6TqRDib2n1N2OdJw/V/7D+CEBCyQn++WVvwdasvBi3nXGBiIbBCEFEBAQE+Fst/q0KTx6MC8NkiAIRCSIhSAmhlFKC1f7Q7uz8iuqAP6Q/999v46PtkkSDoYgQIMuUUkIIEkRENE3G+d/a8f/3EksIwYUgiAKAEqSEMi5qAqGSgvJde/M3784p9mklJf7CIwXtOzSd/uatL70yO9EltWjWKKeo8oPP1/yyblfbThneaOfAXq07tG3iinJGOVUA4JwDABJE+F8IMCGEEAIQybnkpRAg6sSx9ePk+XXq/lwnsugGgHU2ZsPpdVaDQERCsG7mGfYaIiKiEMJSD2ca1qnOkw7WOc+HbvhneIVCCMa5RGndP7lY90v21q0HN20+uGR7oVYWyWwX1zMzuUXLRt5Er02RLht40cLlW/4x/r21W58LhfTK2mB1pe/wzn1Lf8o79EshgA/A2WVg+i0TenTu3r5rhwzrEvC/VY6iAXP8NTxo+D8xDc7zun8wYzHGCQFEAgCV/tDBA3kz5/y4aMV+lZqtmqd27po+sl+75i0bO+w2l8NW/8DmLN46cdTLtz4y7Labhh06VnqsqGpE73btWiT4A+Gwpm3dcXjxiq0b1+/e+csecCVdOa7zXZMvu6TPRRSBMU7pn6XNmcmoRJeu2vfq0ys69235yjPD8QxUtY5W+kNPvLK8aWpCWqIzOkoyzTrnQwiQZRLWeU5RKDev7J/3DIjzuk6LpFgC/uCRkr37C+wOZ2qCHVEmiozWFmUMGAdCmBGWFdKyRerOrNyjORXpafGyTAGIxfyEEgQeDkeqg3rv7i1X/3zAhqxRQjQzTRAEqHRc7HFKRY1P0wQM6NHiLMiO5Vw9+crK9Ut23/HQwKtGdjofsv9hjMWFEBwoRQDILaz4ZPaPM+esz9lWff0tna8c27NDu/RmafEnLTcSMWvDxo+b9t1452fAxZfTJ8fHxeSW1hwpqOzbsXHfrs0b3mpFdWDrL1mvvLNo9aJtAOotd/Z+7JEbmqQlMSYI+eNFl0UWwxTXTvni62XFEGH7t93UKj3BUkOndUpqgpFLx7y3ZVUpAAK4wEtBFwAAKoEKDSAMQCDJVrDjvpQkz2kfpGkySaLzvt1y9dhPAFwAFMANLgoqAhfAAHw1FjEm33nJx29f++p/lj00dQFANIAdwA6A4CIQCAMEAXxXXtv+3fduHTz2v1mrDgG4AVSwK6BRAAFAAHSAAEDVTff3++i1aznnFsRzWmSx2h/ydnwPwqJzpnPdd1McqnROdfEHMJYQAoRAQgBg666j02cu//DNDX2GNB5zRY/rr+yTEB9TTzVERIIgABFMkwUjbFvWsUm3Ty/gZPhFKa8+dd2eQ8W6rmcfq+jXNX1Q95acc0JQCBCCU0oBwNCNb7778cU3vtm5MSe9Y8qbL9448rJL/gy1aNlVR46WtWj/cVKvRlVby6c93unfDw42GJOPq/hTh8FETm7lvG+zvll89EiAU5UCEuYPD+sSM3Bwq1EDm0ZHu23K2SwaIYALiIT1lRuOLlucPeOHAne0yk3OKDKfft2wxh07NxrQo3HzJvGEAONg6lqtxp58/ed5C4+F7TSwr3rMqKQu3ZpcPqxN6/Q4Sabbsor2HqosK/F/vzJne25QdkiAwgiZLaPJ8MHNuvZqcmmvdMtoOS39TMYlSj6Zu/X2W1d6uqeUrMhfte6qgZe05Fyc3TKTLlDdcsEpIYC4a3/+S298O/uTbSOvaL1m/cM9u7e1ybTO3mKcECJJtN6ItbgqJ7/szvtmlEW7Ibd6/MguYd3QIrphinA4EjFNRLCwBkQAoEIIzrmkSFePG9Knz0WP/uvdzxfsGXXtq+++XHH7TWMZY4TQP5C1OBeU4pff7Fbs1IyYkOZYvCj71sk9E7wOS2Gdlhdlii3S46bdP0C14YPTNnvaeSkI34GK+97t171nm/MJJCACRXA45NGDW48a3Lpg/PTl2RHqUDRTdE9irzw9xOVQ6ydTIiS7IxgO7tmWV5FV22Wg+5XFV3S5uKnbIdcbhl0zk7tmJgNAs2T7uKt/8HSJZQCBY/6HPh02bkT7c5qVBFEz+OKl+7Uou1MzlFT7x1/sHHBJywbg4x8NN1huAiWksMz32AvzO7V9Rujmpg3TFs1+tH+fTJtMGWMWKSWJNuRuxngoYpZW1Nxz1/QDJrUDtm7i6XxR86JSnwAI64amM5OxU50XSikAMsZSGsV99N60J6YOBlW947HPvvx6OaX0DzQWhQBE9NVG1q49BgmOYIS5otUt63wbNxxGRHEGyAMRhQCTccZ4fIILbACEACDYSViPMCZMk5/nIoUAw2BciEaJLj3EFYuNZBHQdMaEhblwIRDRXxu5+dav1y3Lvf/RVsu/vn5AvxZuh2yY/LgzC1wIw2CMCcY4KMdNRMI9UQpj3DDZWZbEGScEc3PKFy4t9jR2VIQMJdm15ofc3dkllBLGxB/PWJzXebxzl25LH/7qouV71vx875ezpnbv0oILwRgXQlBKT9qgAoBzEY4YvoB2970fri/UklK8vkMVN1zRhRC5xqdpYTMcNsOabpq83hE7yWOnlDLGFYn8e9rN90/qBap6xyOzDhzMIQT/KJSLcUYIbtuZu3pFhTte1ZjQIgxaeF6bvk2AOK0tUi9vEJFSotptAMi4sAhMkFCKv8FXRySEUEQECnXPTwgBBNEiKueCIIbCxq13f7Xgq70vvjbo1Rcuj41xWpSXpROivg41pNiAfxA4VFaFKSWEkLMsyRLMC5bsA4KUUhBAFVJUxpev2HsCV/mjGEsIy/XD/DL/5GlzJ9w6+9U7+21a9lj/Xu1ACOuGKSWnt3AFhHUzEGF3PTLzh92VnmbeKl8oziv375tZVukzuRmJGLquB3XDNPhZ1kApsQTx44/c3C8z2VcJ9z/2XiAUPh4fumDUmBABsGDRPnBL4SADAI1xV5xt26byjVvzEIGdi4MRzkH334hynOQnASHoD+rX3zR3zic7/vP+5Y/cP9DSIKelfD3TnzgnQbtdPjd6gqhFjJmz9+oOW1WZBog+jUFzzzsz92phnVJyFmL/NsbiQgAISsmyDdltx7xx4GDRzmX33j15sFOVGRMAZ4TaBAAiRCKGzsS0Z75YuPyIp1W8rpt6aWDkkLZer6e8MmAwEYroWsQMRSLMYOd49oicixi34/Vnp4AHVq48sv7n7YQQCz69QLOdIFZWh95+JevaCS1euq097KnxOigF1Ay68LvdzNIzZ+WE2kAYONA/B7AlCEHNnHLbnG++3DXji4n33trbZPw3ui/CpuA5kSNE+GlTTsHO/FnP9XjkmqZQXGun6HHIeQe0rxftqQerL5SxLGkEiG9/smbY5dPvGdF25Wd3dWyXdlzxnfG+hAAECOuGCfjam1/PmLvL0ynZF9IVSiAYHje6W1VNQIuYYU2PaEY4YgY1nTEG58puoJQwxjp2aHnnVd10jc34bLkQghBygULLMh2+XbYPoGb8sOYjRrVPSCOaxjWde1q6Z8w6UFhcI9FzXCUSCgMRQBD4yeLidw9E5EwgohbhN9/91VefZ300Z8I/JnZhnJ9FUJ1VRpxNTiKAwcWiRXsBSP9+LceOaANFQbuNMJMrjRxfz98dCpsW+n9BjGW5l9WB8D3/mnP3pK/nfXz1c9PGOVSZcXH2u7LAw1BYB0Knz1jy7BtrPZmNfCHdJROtLDC8X9PGTZJKyvyMsYAe0SKmFomEwjo32XkujBIy7LKenmhpS9ah8oqqCwQdLLM9GDaXL9rrTYrN7JDSJMk9amQGKw4oEjKJVtSyOQt2nZPpOQfg5MRjEuzC2SpimKoqBULGlNvmzZ6xb/6iSTdd3YUxRs4nIvNb6cAFoaSysvatj7JGXNUmLTm6RYvkXoMSqsrCTAhXsn3RvKJtO3MAzmjXkvPjKk4IVvpCdz366dsv/7hm093jRnVnzPIKz+0/h8O6XVW+/mb9A9OWejqn+cIGAIBE9fLA5cO7RHSjNqyFwno4ZIYiejBiakGDsfPSaIRSLsQlPdq3zIwrP+Zfs26ntQcuAGXglOLRnIqvZx+cMjkzrVG0EHDn5Iv1Io1S1HWmpLg/n7e3NqQjnom3OADkl2gQJmAZ7xoiSnAhVhcB0HmjGFUg3HT7V7OXFLoyEvfuLWJcIOCfl7a28scjdl9g2Kj2BMHrUcdd2U4pCSoy1QwBqepnc3YjAp6BAciZcIT6wbgghFT6QzdOnfHlh1t+3vBA/+6tdYNZXxVnHQAQ0Q1VVRb/sPX6W750dUnVIiYAAMVAINKieUzPLq2LS2p0gwU0Ixg2arWwpul6JMwMgzHGTNM464eZJjNNl9Phjo7VfLW5OUWMMcMw6ieYpmmhHuevbgBg4ff7AIz+Q1tLFDnnGc0TB4xK0GrClKDbK2ft8K9dd4ggnoX7TzA3F6BRIjkuRCFaFtSBIjr48i/mrS7xtIxmcbZ/P7r5mddXISWCwx8e8EUEg4vps3ZqdveooS2tpzlmZFudCt3kmsGVRq75i47m5Fcjnv7q5ExR8eMDKMHKmsD4yW//sHzXps2P9OrSAgAUud59PttgjNkUedXPe0dP+NDbOVkXXAcEAR6ZQpHv2tEXgYSVfk3TzKCmB7RwSNPDET0QDHtcDkqposiyJJ3lI0mSLMuEkPTG8QCaotoopapqaziBnsX6Ox1BQ2Hjo492ZvZsOvSSDEvIuJ3KNVe20w8HnTYSNoQSrS5cus9k/CwqqO6CBOocJ5leeABbVTEjIxqcqDOhGdzbJ+mphzZ9/OVmQvGPzSZiTCDi9l2FO9YceeThjnFel8UVKcmxt0xM14pq7TJx22hVAVu4bA8CnhbQkk4yhgyTH8wtC4b1WLfd6bABEGaa+w4XDxuaee+dl7nd7k1ZOaos43F0xEJoKBIgQI8nYCAQBGFy7nKou/cdmzh5ur1dUgBRNzkgKgi6wZJccu/ebYuKq/wBrbI2WFMbqKoJ+mtDwWAEJDpn8c/Ze/YLM4IIgKxBYgHW5Y2csF8QEXftzfe0bf396p21VZWMcUlRKJX9fj9CwJuQNHrU8JbpSecEvk2TSxJZ/uPBnH3VT7wykAvQQgYASBK/uHtzb6vt/gjXGbenRH34xbHHHvY1TY05EwoPp4sm/u5BCYAQGfH847dG117/5bKNVa7GnqoQ83ZPuvvulelpMQMuafmHxuOFELh+bbYOpH+/VqbBLD1jt0mDh7T57LM8J8GgzpV05+LFBydP7OFySKfSVmq4ySznzut2fP/T/o37CgrzyrpmJDZtmdok2du9e9vaYPiXffkIggBQiSqSpMiUSCgRKlGkhFJCJAkIEEv16oaZkiSt27C3rFLztGjkC4StjaxINFBaO/KS9CinfcvegvKqYHmFv7Sm1ucLlVXXlvkinPEFmwsWLMkGUwBBIAAEgAPUe8i8Pp4gQEIwARp5PPFNVxwNrdi1B2SEo2WgF18ysN2NNw4fNay32+0+pzdu7auIwVatzIYEz1NvbH/5lS3MZABICYBL1rikqAAcFIqMiAULs6be0VdwAfTPT17hADaSU16rR8zpb1512ahZ+8pDdq8jYHLaOHbsmAU//XRj+zZJfwhvWWCYPxB+bdZ+PT522FULXETonFt+kqZSiLVpTIDOPF77DwtL92cXXdy5CefipAiqdLKFIaBRvPuuq/tEfffLNpu0aPnOvDlburdrlJAc3TYjMb1xosvjUCQKAnTGIoZJESWJKjKRZCohJSYQtOw5IgDyiyuuHjdgxbojW4v8do+qMQFC6AAQMXt3b5WdW15cVlNRE6isDlRVB/LL/EcDBiABItsTvEpKfJ1GEQ2hwvq0KGSAAEhBUAAtrFMw0hNdNYqh+XwjJrS/a8ojvXp1ls/7qVsELSiueueDAy06x/frGh8KG5RQAUJwkCSsrjEW/liqNLLrBoe4qLnz995wbTev2/ZHlRIJISzk80zJKw5F1iMsrZH7u68mDho4qyQUAVUBiepJzmFXzF619IaWzWI5E+TCGN3aKes2HCnZXzl0XOvG8aqmm1awgXHuUKWCgsDqHTUQbWOMK8nq9M+3d+vS5NTERulU40AIoarypDHd0tNi4xNi1m/av35TAeTVLPrxEKhSZor7ouYJKWkJyUnemGiHoFLENLUIF1wQSilBRaaUEAAgFMJhkzNx580Dr73nS7vHDiCAEj0QyWwVG+2NOpxTVukLVPsDRZU1h/JrK3QOCrWEk8aYZpqngtn1OtAOQgFGwVDAJIK7EHTDOLq/7NarMq8cd/2Q/l3rUb66rPnzQ7iXrjqkBGqenDpi4piOJ02oro2MvmrmLwU6c8rueNvm1aXbtucMHdDaNLkk/TEw1dlZQghBKHImmjeLXbJ0wqVDP/PHResyoR61oMy46e75i+bc6HEqF8joKIABfPn1XtD59JcubZISc9KEQ0fLWmbM8PRStQijjVyrlh07MrUqvfHJVsHpjXfGuM0m11TV7N6X17Nry0v7NgMFXWkxiteZVRH6dNWhFz5a/9SbS16dvmLB8q0HDxX6a8OCEEoJY7wmoJXXBCp8gfKq2oAW3n+01B3tvv6KjlphjV0idgSo1XtkphaX+YorfBWV/oNHKrYdralgACo9ruYEgLDKJwARkAISBdAO4AUjCcLJGIqF2igIxqrokCVJlk0qRSnylmVPv/PWtCH9u3JeH688X+QQAcI6m/Nllu7yDh/QAgRY4V7rYxgsJso2bFhLyAvYZRrUOTR1zJq9UwD8Ogz3+5w+IYRYtv7QyJEvHzxYasmGMyMsyBhv3yblo0/GBI5V2wlqEeZp5P5ps/+ZZ763dM7vXg/jghA8eqxi1XfZN93SLinRwxivpwNjgpk8NTV24uTGWkFQkYjTQXOyI+vWZCOc7COfHm4gBEvKqu94fO6+A3mJMTabxzn24vRAVVA3meJS7QlRrhRPhUPdWRKYt/LAU++vmfrGkhmzVn6/cnv2kUItFEFExkALs6oardqv7TlY2K1L86bJUZpmaIzHRdsSkmJzCysLCis3ZxXuKqrVJQoUj0dbCQABQgCIIsAlTK8Ix/FQAoRiIeCmukS5JIHNYY+Och4q9pVV+F1OW1HWgcf+0afrRa1AcMYYIfibwGhLsG3ekb9uxZFpD3aIctuttBlC6j6SRISACWM66ipqJtcMpsQ7Zy/Jy8mvtpyJC9I+jCPi8uX7lywp1jT9nIAXIciYGDaw9bv/HeDbXOpxSL6A4Wkd8/rLe96dsQkJcs5+tz4GhA0/Hykr8w0Z1tomEcvstohAKQoUdoWOGN4GqjRFJv4wV9pGzfxqv6azk6IR5AxBIlywdHPFrtKbR2Tef8OgIV2a+nU2vl+rOC70kMFABAwGgIpTsSdG2RtFg11Zl+v7dOm+Zz9Y++zbyz74fO1PG/Ycyy2u8QcjhlFTEyqrCg7o2RwiOug8PTW6ssq/cduxNVklBTqAUwEkAAQoASHsgtm57jWDCTzgFUE3hB1oOGQgCpEkmUuSy6k67LaK8po9u/Ju7p+xcsbdSmVZYwe/pG93zgWAlV3zmyO9jIsffzwAAP0GtqKIJ0U8EBFANGsaO3l8M72o1i5Tl4xKNSxevh8RGvrbVknF+QBLVqYaY0yW6U9bcj794qA9LhWVE6lUnAtA0tD6qV8VIcgYv/2GHk+82N33U5nLIflCprdX4p1TVi5euZ9SehIEUF/ocRY/VQggBA2DPfPezrimSX17Z1gpKr+ynCgVAkaPaO/NsFf5dJ1zGqWu/6H8wIGSk7YDOYNToH2/fKdip8MGdwbEu64bcMOITrmlvn5dm6Q6JD1oKBIFAJ2DtX11QCXK5mrktjdylxB5S17NZz8ceO2LLdO/2rxo2a4tWXnbs3MJiszGXjCZTSHLNuXsKtV0pwqUKCa3c8PFtTgzEMcDHhGMwYhKhESIJFOiKooiyxK1UckVZfPYlez8Sn9O0TV9W2745uHp/32gqLB054bNEyaPzGiaIgT8JrfISuMxDC5RDAQiz7+wa9Dw9F4XNzEMdnLCjxBW8dnE8ZmeWsNOUTMENHN+/dVuXyCCCIbJmBBWiBMRFeVEuks9ZGqanB0fVt4RpYRSunl77j9u+VaPdmgAVCJCCM4FCEEIgmBg5RJzoShokyVLK1m8ZRps2gODptyaETjsd9lIwBCuznF33rUkJ7+KUrTSv7gQnAtEkCRyahSfMc65sK5omAwRt+0uPLKh4JqrWzeKd5mMnyQ8hRAmY05VvndSeygNeBRKiVC88vSPN1l1oJYFchrjnXNBKcnPK1k0Z9cVE9tkZKRZV73h8h6JsVFPvLusU5tG0blVe0r8isum8xP1SToTulVmRFGJstEoGwUoM3hZSS0U+wHQY6dRdllxKOtzayBs2GVBgyEqBEUgFIlVP0hkIIQLUCkQsKxZQShxqpJpsJz8ShYxHhnb5eqrBnTq0BwBKqr8Tzz9iT0u+c6bLgcB5Df62giApA57e2/WZruTqE5FlumpviQiyrIEAM1bpTZq5akQqMhoT3Kt21q+YGHWpIld6fHAuG7yyoBeWa17Gqk2ShUZvV6JyhIhaLP9itolVdqBg6UbNhx+7LWdEO+0O6SMxnqUQ0ZEWaYGF8vXHFi/rdKVYAdAjyTVlOnlFYEYt6Me0pNkCgDPPTd82c8zaimljCkuW7nPvOXm+XPnXR/jVq17JDJlAlZtKPI0cskSsSFSVSGEEoKE0HqnTSE0oBlvv7/Zm+ryxtgAQJboaeggUQC4uEtTj7nLqUrhMFObxyz5Pvfna3N7d23SwAn4tUy0/NX3Zyy+d8oH9z0x5qUnbzJNRinlQlCCO/bkTn1pAZFoKKRvPlal2BUdz+BgWe4noQqhlHDQDc1y6AQDlO08QpmpAFMkJIQQCQlBDlTi1tMBQhCIoJQ6bDJjfNfR8vYqGTms0+Rrh7ZsngIAhsFkmb769pcP3f3c+x8+e+uUsYyx36QErWjV5/M3rfy5MDer9Kc1FZAcBdV6l/bO9M4J7dt4p901mFJiOVm5hdXfLd3244ayw7srsvaHIF4Ga1NJCDn66JHe1PYJmZmJP3yzv6Q4VFJjHN0XhlQFTIAAQEBPzlAyUmwgOEqESsgB9LAoLtFzDtUCSErHGEVSAlq4Z2O6cN4/JMaWrs766J2ta1b7oGkUqAhhE1QJqszWMWL8TW3HX94uLTkhyqlUVAaO5hd/9/2hF97YC7EqGAJAgINCUeTi5urEKe2uv/LivQeL5i3au2t94U/ra6CxCiaAhBDgGWm2zu1jHQmOK4e36tG5ycdf/Lw1q2rXzwWH9gUh1QUFkctGJ8SkucYMaTludGcAwQVQgnsP5s9ZuHvXloqNv5RVBAQ4SN0JQ8IliSHdYhp3iHts6tAEr/1kxmKcU0Im3vnG7HdXvD3jjjsmj+K8Dnaz8Lf8wsrbnppdUh1SVWXDkUpQaAMwAEAgIAAhCnDKOQgGYQ0iOjicmt0JhunyV+jRiXqdeAcFuALCIXEHRZUIQgEQuECJol1VNE3PKan2yuT+Cb1GjOzdvFmytQwuhCzRTdv29+w6pe/wixfNeyHKof6mhCTrroO6Ofz6D0Ih6NU6vkO7ZMMI1/i0PYcDBeW1gVBo06J7ZJladz13cdajzy+4uH06CryolcfloIwLSrGy2jhWHD6aF6gMhlwO0CNKepIjMc7WNiOKcU4QnI4oJDQSMUyDIUHd1EOhEJVoOMwP5mpRDrnSZx7MDxZXRCpKQzdOaDLjjXHPvLTsqWfXdevXXJWpafIErxIfq/gCZnGFXlKhHyqqgiOVb80ad9eNF1954xffbDzYp0Ny86QYgdwKeggOxeXscEHw6IZjDz3b71BO6d6D5R1bJHdr51FthHOOBCM6/2lr9erdtYGs7HumXXLF5T0m3jWrfUZyt5be9GYJoVBtcVn4QH5o37GioX2avfrElQiCCy5R+uFnq1+ZtalLi6aqRDJbu2UELoBSzCsJF5ZEjhUGj5WUffrWNUN6Nj2FsRinlIy+Ztqi7/f88N2/Bvfr2rAew/rdF9CmPPLxL3uKvPHufWWaTggQVAAUEApyYJwZYWaYjJmgG4za9OhoIBJwYdeDdqYxm8tHbAC8zp8SVpQG7MAVGWIoRDkQmDiQV9ExwTludLcbJwxKiIuu8yoIghCEkBp/aMz4e3MP5a5aOTO9Wco5i0bONIIRQSjYGwBRDMBkYBjcqZ44I+NC08GuohBwEmhlCME5MC4IoAAhSyidH3+bAgCEYXLD4IbBBOd2VXba5dqAbnBQ7ZJgXAiQJJQlanJhGFxwzjgwg6k24nQoNf4wEKraZYk0KG4QYOicca7r3CYjEgqE2BQ8adkRJiIR09R0m112OJSgJhQFFPorOkR0QRBUGQUACgCEiCFMAaqCACenMRpcMCZME+w2pASlU5wFFIIJpoGduN2O0zi6nHtc9pkv3/Tqu4tmLNye5rZXaybhApjBDYOZTGeMCQQKCgCLitHtThAmMFNBsKMu2WwqMXWQtboCS6tQXgCAJlAzwKdBWxlUWbx//4ihl3ZLSYytZ6l6xcSFuP+R19Yu3/D1wnfSm6VYYMHvi/A7bQhQZ8PWoZQUbRRslDR07SgBl1p3CdM84TISRIki0rp4HgARQnDG63OXxWlSlo97WBKxftplCiDXi9Iol1I3Qz6eQALCRsCm0uNPU7YOR7vVE/IXT1xDtmY6fm10G7+KVNskYm1pFEUAABZFSURBVHPI4Kg7lcuOIAQzuXVvFr7gULBeult/bTLaoK5q32gAXBGCEkFZRpDR8oqlk2OHEgAQQAYmDwa10ybWMcZcTjUtwVZwsDguI07XdAbAmNAJKpRQIitUKAQDNrcuScAMy+qzC1OlxJSoIkEMZ5qOJ7ukCCBEglMuqSh/5b5RkycMqkeYLF1sefGmgAcefnPm+x+/9cErV47qb6WSXiDoTSmeap6dqlitI5JEz+wMACIiRfJ7s5JPo83PoOAbHD63CYBYZ+mf7aKIVEJ67iUhIgCCfKabREQAqawicFIuFiXU5DL4xcHDxf17i5MqyCwbedGSn6ZMes/bra1fM4EQSlGRUQGkCDJyTmwB1alzDqYJaOk7cIJJZFlFShCibeA3RUCcvq8HEYgoOK/T6/Va2KqBmfavt956/eNHnn5i3NjLSsr8Vrb0hUfqzixZzjLt5HjT7wVL8fzWhhewfnEeFxXntzBxjsQjzm02WUps9/6vUC2NK42iEzwUdHrsaCEiCsF/DUbQrVmHRo973dO9tc65IiMgUEBApERISEKyMwA24KyuggIAAD3A7bIwiCQTtIoyU10iuxrAdjwrvKFnShEJEIKCkYaWn2Gw++5/7d235zceMvGbVfJL774P/Hjiw9/jrzC4AEUC0//ovR0lb8vYX7EbM8HmjLbH1mQ4tmzZV+kLeN3OOsuGC0So8tXee+9rroxEmUrATZAQACmiRAWgXIt2DSgIVhfpO87iHhsjRJKRSFZZHGKUShNsrMw8HfiPyMwGMX/OKaU1/uCDD742Y/6P7cdeV1KTUBLye5rHUCTwd8OsvxJjEVWSauU4r0uqyis5OaXUrGJ2QR3K6mVHdmzfO3hA9xMF7IiP/PP9DQeCCS1SI3pEtlGORBKgUAgTxc8VXQgA9uuWTuBC4ZBBIJEJIWjlNxGOkOalZcUMJACODRcnkTqLhwtOgFBKt+7MvnXKE9u3HUntNObgbqEHD4NKdQ7wN1v91SSWTYFqf0lZsvT9x6NOjRVSyf7RR7OWFta++ta8fpd0lShhjEkSffnN2R+9tzl1SKtQMCJTiSAqBCQCAW6vAgqCW/brr/SxCQlRwkapgUgJJUQgoEwEF+hQpaYuyAkwsDVQZwKsmmYhhCxR3eSz5y6ddN3UPv36Ll39MTIX57VEkv5ufPsXHAIEEmJoZqNkj3TZoNN3hnCq4+Yvf3zNxtwZMxbcdutVkkRX/rj1kSe+Sh3UStd0RSIAqFBhglzOZU0QYL8WVCBAoEeWnaqIthsGEIUgRaumFQGAEGIKkeylRQFTbyCxCKJuMqfdhojZhwsfevTlxfMXPvH0Q1PvneQ5Bf74e/xlB/33v58QAk76cM6bNklGM7hq2d4l67P69WguKcpVY5+WG6ciQUAglNgV0IlSZCgmIKAAxDpkSgg7kmhFChlmpKpSNkNut8tuVwQXlBAkCFJdDwIQxKVSInhlgCsysYK2KmKUHXp3bvbzT1tHDJ0UHeeeM/edG64dqdpkCx06dbUX8rGyv076nR9v3nHar1jpU2f6Xy5A1JdK/94lWe0IeIODcLoJp/4Op3wdTrnN069WCAFnnH+mr596Hksf4pn6Y9XN4OIfN0/7dOa2Fhc3VWO8eWW1MfHRYZM5JSQUq3WlwiCA4rjqEyDAJUkqhQpfAHy1/TKirp/Y3+1y/uvl+RFVbdI4To8YHIECEgQkxCpLpIg/HQnqBOpYM2QOyYz9YcseV/GeV5974JoJo90u25/XGPJ4f06EU5p9nrZ+HAHPlPt7UpdOcbyDKFosCKKuTQ0CaZAMY6VAieMdOBqQv86bsn7nAgieoED9jFOzMBoebPhwG860Wo5ZR06ZjHUXrWuFCif3MrHwp+OLEUIIDkig4V3XNT89YzQNsaKy5rHHXv9oXXlSokdSCGHCLoMJtDQsBwQCciBWgh56bZKuG4GaWi+NDO+ZMX5kj359OrpdDgA4dLTw9Xe//XrdwTatklWbHI6YSASi1fIKnCopqoxkFUUUB9E5uIRoHk9G92wxZcKgtJSEeqzhT2ApYCajBPF4UoTgzOQgS7SyOuRx26UzMNDeI2VxMc5Er7NhEnCDHpKiuKxWVkhctOs3I2lCRCKmLBFqYbBCCBDYgAuFEIbJKYH6cDszWcRgdlWJRAyZEipTADAMk3GQpV+lplnJBHhyu0tRUu5nQsR47A6b7ULs9pLyWtUmRbudp89u+FUwq65z4bqr7/64bae0sKarMvVzuSBMAEChQucITNgpAWZo5TWtU+1jB7abOKZvq5ZNZIlYbp3gQClhQsz9Zu2LH64IA6Q2imWCI56oobVLdFO2rwoACCZJVI/U/Pzxva1bpBmGKUn0T2gDCQDC5Pifd1esXnmQK9E2py0cCFOj8p//HN3r4mYDh77liFX6907WDdPldCqyAkL4/QGBTJHsL7+5+b+vj7nm8o4WfU6EtMPsv9N/XPzNjiEDkg7l+bO2+LoObP3uK5erMr353vnl1eEhfZMopVW+8JINVVYalESI14lNkuVL+7cbdWlbf0Cf+fGKrdvK8v0kKsoerK5VwDhwSGvSNvbygSnXXN09KT7q68U758/dVByye9yOiKHHkUjHjsm33z5k3tx1a9bnVQi1ssjfIcNxydAOKxduzisGT2IU47yyoHLEkMYPPThKoUAQDS42bjryxvRNh7PzRg5JYQBrN5b4iiAxPe7TD660qdLQq2f37ept19ILBHLzgqt3V0sInAOlmBIrNUlSr7+mZ4dWiUIILcLefG/lgu92D+ufvO9ozaGd/j4jOj73r6FnZCwrrJt9MHfIVU+R+HiHTASQckOuMgAIKAT1sADkCU6qBn0pifY7ru7Xo3v75k2Tj28skxKCiMLqSSJAlqXi0qq3Pl6ydn+x22ETQhiGKQC4AKeNlFcZW3IDYJcSqMRN38LXbuzRpS0XgpI/pXetdde1QWPr7oJBo+aDBpcMTJj+5sjWGbFrNx3p33P6/f/qMbhHsgD8bN6uOZ+UQAKZ/nLPlHjnqk0Frz+zfdGqG0YObGUyZgUGGBOE4tOvLn/yoZVffz/pysvalVWHpk797stPduw79kibprGbtxyrqQw9/fyyDesD3Qd4X3x2uJUMSgkpyCu/9prPbrp/0EevjTUNJsn0y6+2XTv+e1Ck597oc8XQ1kuX7Xng7g2QCp1buefPur5pqienyH/jpM/XbQtBILxm9dX9e9e1pt19qKxjy/88+M8ejz48NDZazS8JPPz4kjkzjkIc/fzDy0YOau12yZyDZrDHnlr81os77Y3VJbPHD+iVDgC7s0vfe3/D+2+u+GDmdTdM7LFx45HDOWW3PLoGSsSo65o+dGcf02CASAlZumLPS08t+WzxXdeNyASAaf9e/Pwza1dvvGNAj2aFZYGbbvt6+YJjB47dK52J7ohQG9SmPvR+WHGkOOWADvmapAvwqJLOUKvVWifZ0xLsmqa9+vKt3Tu1OilYpMhyw/BiXVBVVcaO6nUg/7u9hTVORYqJsssy1XUzHBGJsUpCBS0zBFEgYkBd+fKfhilYeK/bpaSnRbtiFUZIahNP64xYAPhl8+Ep92S+9vRYa6bPH1m8PhQdLV99ZW+3y9a1T6cZH+7w+8P1sQ0rK7ywtPbJN/amt0jr1ikNABJiHI/9e0hBZSk3GAB0v7gZACxYun13oS0l2dO/V8aJpfRK/yW72GASADABVAiJot2uQiqNj1ZbN49rfVf/7buKF+8ObV9VsmPLoSapXZsmu59+8rIrrvlGi/Z8uzS7f+8WEYMpEt2/pyAuzvbYY5fGuGyRiJmW5IrzqvZUO42h7VoneaKUuiS211a99d4+JcH90RsDBvRKNwxGCHRonfjef8bGxWFQD9kUOqBfyxatEjJn7jimYqv0hEt6pJ9Yb8/0HXuLZYIAcDCn6tMFB1wZjds1jweAlATXf14ffosxW0YhnVZTcM4BycOPf7B2b0mbDmkFPlHLFMVGwWS+nEqgxogeyYHyyh+WHIYS7cH8Q82aJNnj4pumJzVJS/R6ouyKQiSM6HooEikqrSooKDu4P7+yoHj13qOga+2bJ7dt06FDl7bzf9ipSKRRYkworJtcNE+ylx0NErugjP0POphbhW7hiBkwGFChabolxm6a3F9RJBAipBk2m+SrCQbChlIrKir8Drs3wW3bsel+j0f9VfBbgCSRjBSlqIpPuumru+/o1r1L49bpcWsW3WcZ7BGDSQRDWjgQMBp2K1uz9sA383e+8OIVAc0AAKttgeBC0zhEQLXLAGAwoQVMX7UGoEdFuxBA11nPbk16dItbuat27twDt/+je4tm8UzgGx+sv+OhbjEuG2NclqkQQteZpnMlDCFNF0JIEjmcWzVzZpa9ZVxLKdynVwZjQpIIIjIuKMFnHh9jmXqMQ3V1KBw2AiFs6MTMmreGmcrcjydblr3DrjidUqUhxk+ee9/t3bt3adyqacLqRfciOx1jWSGU6TO+e3/OhsxurY/4JCopWiAEBaV2O/vnhM6XXtatX6+O+YWl27ZnV5eXHzic+/XK/Ufm7wAtBGAAmMchfARFAa+SnBI7tEebXsO73XDTlc1bpGW2TXc77ABw5ZDOL3+wZPXu/NZNvIYQUU6a4KRhnQdMocrKOcOdf4jcqjf0rNeqcC687jobVlEopYRStBw5SqlEKeOiWRNvQz/LqpZLjHU+dNdFt924YrXPXL3ne7CrkwbFjx3ZftSwTCtdhFKCgKDSshr22YKsSMQUhr7wm91F1brLIbscDfrrEQTgLo9z/fqcYE1w+47ib1ZXNE6WH3i3f7++rayiBErx9lu6LR23pCRK+vSLrc/9e/i2XfmblxfNmzVJCECCVl/JOvOUQH1xZfbBsrxsDh1ZZjtP4yS3YQirg7rVNYhbGW8AlCKRCOMcvGr2Ed/n32aFtUgkbL786vq77ugVHaWAEFzw1ETXrdd1uP/uH9f62Nrblyp29cbL4seP7jRwYBvpNLA7JRs37Xrg4c9a9el4WLNplTVQmDegW+yI6/peNbp3kyYpFvOlpSSmpSRa35r2eESP6IwLzrkl/AlFQCSUUkKoIkU71V/7ugIAMls3+fjlW7/4dv3zM1ZQWclI9WQkqfvywjoKxhn8Xwys96bPoIcJnsizOHGQEi7Ejdf0iHI7vp23a8Wuat++0KxI8ax3DzzxYuG/HroUUNQZdjIprois2lQQ0gyJiAP7fa07x3MhOOMn5VUzATW62Li1+NN39yvp0ddc3vye2wfwuraJgnMx6JKWlw7YtOZg6NUZ+56adtmHMzdcd0dmSoLbyvg9YzNLkykAOgNCZct5axgpsbC3+jvjDMBG80tDKzcVaJphGDwvj7tdDqsKQ5KpEOLu2/s2SvEs+CZr0cYq7YD2oVb44aycSZP3SCfJKkLI4WMF4295h7XLPLDfB6zyit7pk1+Y1LdPJ3eU63hUWFg5d5xzLgQhJMphA4ft7MayyTgCIJL6fv+cc1mmk8b179mlxfPvfPvdxsPdWyU19dp3Hauk5P/gbR7i9HjPKbxFTvOSHERUZTpxzEXXjLloe1ZRzqHiZ/+77YDD9tTLe+6c0sdq2EIoQq3RpVfMrJeGWV+c+9UvL772M0HEhjleQgAQLRAeMzhj4pjMivJPl2b5Xnpv1+AhGYN7t2BMUIqMcbsqTZnUefn45a5WzjumLd2zv/D5J8dQgvX9pk+7MTxxLj1OKHZaVVOrhQ1FruvnYSGk9XlvFjlsMoGiyNDLm7361GXW1x9O0orLq62IryWuJUonjO08YWznrbsKDmcXP//29mMBPuuDrF9hJIQQDuLOu/9TkBXwhCofnZCxZe6Dc2Y+NnJYH3eUy6rssYqW4Hh/bFmSKCENe2LVVQ+LE4iu9S1Zosd7Ch0X+YRYb91plZ4y85U73nlobG5RlS9c63Uo/xs2EkIQAIWgQtACixvuc6sJpyRTaxdbCOdpy/EAoFYzpz2xYO2GQwjQJTP5yiu6fPfF1S29BCRAAHacIiBhbSgSMpgeMQ2DjRjW6ftFN2uG+cC02dt25Ft5sAioKKgQrPKFQIipt3dXykL2RlHP/nuVLxBBEIwJKhHBxbBL213cO0qn8ofvZKsOb/+e6ZYnAXXNugUhqBCEOr4Rpskv7pg6pJ9Xr9E2bAlu3pFvVYlZ73YgBL9ZuP2hJxcZDBjjnDMTBADoYYNzEQpFTJM9cu/l998x+HB+5X33f5lXUhvh4p+Pf7VtVw4AdO2QMuHqixd+OV4xGdiP15pZBAuHI/dPff7IwcJZn0xcP++hF56+vWvXdjKt69h+1o68J0Zd9TDWvQvu7D2oEZESwjknBK4d23fJB1OHXJRatePYn/1CYVFXwY8MQOdMrzUlmYIVaDo+VFUWANU+AwAlIZx2tb5W7FRJFwwbz7+/57b7luSX+K2jNbWhXT8VjBqcEB3jlChBgggygFBVWZWpYpNkmbpcSqzX+eqba994fguV6whGJKrrTA9xEGBwHNC/5dBBSWCItbsD/31vLaGEUkQLplHlqXd01/N8oOKjd3ZvWFwvSwQADcZ0nSmMqQ7FOrmq0NeevTw9WlTl+Z98fnVJuV+WqSTRcITN+vKXKy//tKC4WpGQUhId7bLLEhAQlBCCDodNkmisxxGO8Mm3LfjllzyvW60N6S9+sHvq48vLKkOWBq2oCVTtKW3dLhbrozdciIXfbywvLrvpH6MteMZkjFh9Rv4nr5mqR9jfnfFt+zZN+/bq9LtLJM4jv0MIwK++3Tlr9q5aXwCQmkAv6Ro//qqu3TqlMsYJJYuWZX373fZvfvJFKTTkiwy/JK57j7RJ1/dx2uVfpwUJEBDUzAef/37Rd9mA4tE7OgQDxnMf7btnYtu77hgUF+NYuGTzkSPFH808cigoezibMCIpOSmKCTDMwMr1pVvWVA4Z3fi7r/8RCZsfzNrw0/rcsqqATZLzK4zMVs7XXhjjqwpcfNEMT8c4X37t7TckTntgZEpKAuOcEFJaFezd553ERMfSxTd7nEq9aj6YW/XG2z/u2FMmI4noRlqa97KB6ZOu7U4AKMX8Ev/cuVunf7kr6DNuvrF5SqL7s3n71i/3dRsU/e7rY9JSYhct3ph9oOy/nxXqitwiCsYOS7HbbYC8yl+zYFl5wZ6qf/6rz/NPD/cFIo+/+P2MOQdSo+gDd2aWlGkfzc6++YZOd93a/wRAyrioDWjRbsdxuAH+JHDybLzFubVtA6GIy2H7U6/FBezfX2iaPD4pBlCEQ3plaVVy48SUJLcVztq7r1DXQq6YGEIJYzxU49cN1rFTumqjp4P9MBg2S8prw/6A3+dDJLGJ8S3S4wHAZOKnjfsU5NFeL5FkwXmoNmS9egOBORyqJFMmsF2b1EDI2LcvX7XZYhPcBCEQ1IM1vkZpCYlxrl1ZebKsUFkqKy5s1iwlNSWuLmUcYU92vkRJmxZ1pUrWYkrLAwU5pbFJXpsqMS4qiqqJRNq2S5UIWlYaABSUBnzV/kBNtWmC221XXB6ny5aa4KryhTZu2pcQ44ryRAMhzDRDtUHLSKCEOR1OkzOH05HeLAER/CGjojKg+QI+v59SGpsQ37xZLAD8PzE5Ku3tIC87AAAAAElFTkSuQmCC'/></center>";
const char HTTP_PORTAL_OPTIONS[] PROGMEM  = "<form action=\"/wifi\" method=\"get\"><button>Configure WiFi</button></form><br/><form action=\"/0wifi\" method=\"get\"><button>Configure WiFi (No Scan)</button></form><br/><form action=\"/i\" method=\"get\"><button>Info</button></form><br/><form action=\"/r\" method=\"post\"><button>Reset</button></form>";
const char HTTP_ITEM[] PROGMEM            = "<div><a href='#p' onclick='c(this)'>{v}</a>&nbsp;<span class='q {i}'>{r}%</span></div>";
const char HTTP_FORM_START[] PROGMEM      = "<form method='get' action='wifisave'><input id='s' name='s' length=32 placeholder='SSID'><br/><input id='p' name='p' length=64 type='password' placeholder='password'><br/>";
const char HTTP_FORM_PARAM[] PROGMEM      = "<br/><input id='{i}' name='{n}' length={l} placeholder='{p}' value='{v}' {c}>";
const char HTTP_FORM_END[] PROGMEM        = "<br/><button type='submit'>save</button></form>";
const char HTTP_SCAN_LINK[] PROGMEM       = "<br/><div class=\"c\"><a href=\"/wifi\">Scan</a></div>";
const char HTTP_SAVED[] PROGMEM           = "<div>Credentials Saved<br />Trying to connect ESP to network.<br />If it fails reconnect to AP to try again</div>";
const char HTTP_END[] PROGMEM             = "</div></body></html>";

#define WIFI_MANAGER_MAX_PARAMS 10

class WiFiManagerParameter {
  public:
    WiFiManagerParameter(const char *custom);
    WiFiManagerParameter(const char *id, const char *placeholder, const char *defaultValue, int length);
    WiFiManagerParameter(const char *id, const char *placeholder, const char *defaultValue, int length, const char *custom);

    const char *getID();
    const char *getValue();
    const char *getPlaceholder();
    int         getValueLength();
    const char *getCustomHTML();
  private:
    const char *_id;
    const char *_placeholder;
    char       *_value;
    int         _length;
    const char *_customHTML;

    void init(const char *id, const char *placeholder, const char *defaultValue, int length, const char *custom);

    friend class WiFiManager;
};


class WiFiManager
{
  public:
    WiFiManager();

    boolean       autoConnect();
    boolean       autoConnect(char const *apName, char const *apPassword = NULL);

    //if you want to always start the config portal, without trying to connect first
    boolean       startConfigPortal(char const *apName, char const *apPassword = NULL);

    // get the AP name of the config portal, so it can be used in the callback
    String        getConfigPortalSSID();

    void          resetSettings();

    //sets timeout before webserver loop ends and exits even if there has been no setup.
    //usefully for devices that failed to connect at some point and got stuck in a webserver loop
    //in seconds setConfigPortalTimeout is a new name for setTimeout
    void          setConfigPortalTimeout(unsigned long seconds);
    void          setTimeout(unsigned long seconds);

    //sets timeout for which to attempt connecting, usefull if you get a lot of failed connects
    void          setConnectTimeout(unsigned long seconds);


    void          setDebugOutput(boolean debug);
    //defaults to not showing anything under 8% signal quality if called
    void          setMinimumSignalQuality(int quality = 8);
    //sets a custom ip /gateway /subnet configuration
    void          setAPStaticIPConfig(IPAddress ip, IPAddress gw, IPAddress sn);
    //sets config for a static IP
    void          setSTAStaticIPConfig(IPAddress ip, IPAddress gw, IPAddress sn);
    //called when AP mode and config portal is started
    void          setAPCallback( void (*func)(WiFiManager*) );
    //called when settings have been changed and connection was successful
    void          setSaveConfigCallback( void (*func)(void) );
    //adds a custom parameter
    void          addParameter(WiFiManagerParameter *p);
    //if this is set, it will exit after config, even if connection is unsucessful.
    void          setBreakAfterConfig(boolean shouldBreak);
    //if this is set, try WPS setup when starting (this will delay config portal for up to 2 mins)
    //TODO
    //if this is set, customise style
    void          setCustomHeadElement(const char* element);
    //if this is true, remove duplicated Access Points - defaut true
    void          setRemoveDuplicateAPs(boolean removeDuplicates);

  private:
    std::unique_ptr<DNSServer>        dnsServer;
    std::unique_ptr<ESP8266WebServer> server;

    //const int     WM_DONE                 = 0;
    //const int     WM_WAIT                 = 10;

    //const String  HTTP_HEAD = "<!DOCTYPE html><html lang=\"en\"><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/><title>{v}</title>";

    void          setupConfigPortal();
    void          startWPS();

    const char*   _apName                 = "no-net";
    const char*   _apPassword             = NULL;
    String        _ssid                   = "";
    String        _pass                   = "";
    unsigned long _configPortalTimeout    = 0;
    unsigned long _connectTimeout         = 0;
    unsigned long _configPortalStart      = 0;

    IPAddress     _ap_static_ip;
    IPAddress     _ap_static_gw;
    IPAddress     _ap_static_sn;
    IPAddress     _sta_static_ip;
    IPAddress     _sta_static_gw;
    IPAddress     _sta_static_sn;

    int           _paramsCount            = 0;
    int           _minimumQuality         = -1;
    boolean       _removeDuplicateAPs     = true;
    boolean       _shouldBreakAfterConfig = false;
    boolean       _tryWPS                 = false;

    const char*   _customHeadElement      = "";

    //String        getEEPROMString(int start, int len);
    //void          setEEPROMString(int start, int len, String string);

    int           status = WL_IDLE_STATUS;
    int           connectWifi(String ssid, String pass);
    uint8_t       waitForConnectResult();

    void          handleRoot();
    void          handleWifi(boolean scan);
    void          handleWifiSave();
    void          handleInfo();
    void          handleReset();
    void          handleNotFound();
    void          handle204();
    boolean       captivePortal();

    // DNS server
    const byte    DNS_PORT = 53;

    //helpers
    int           getRSSIasQuality(int RSSI);
    boolean       isIp(String str);
    String        toStringIp(IPAddress ip);

    boolean       connect;
    boolean       _debug = true;

    void (*_apcallback)(WiFiManager*) = NULL;
    void (*_savecallback)(void) = NULL;

    WiFiManagerParameter* _params[WIFI_MANAGER_MAX_PARAMS];

    template <typename Generic>
    void          DEBUG_WM(Generic text);

    template <class T>
    auto optionalIPFromString(T *obj, const char *s) -> decltype(  obj->fromString(s)  ) {
      return  obj->fromString(s);
    }
    auto optionalIPFromString(...) -> bool {
      DEBUG_WM("NO fromString METHOD ON IPAddress, you need ESP8266 core 2.1.0 or newer for Custom IP configuration to work.");
      return false;
    }
};

#endif
